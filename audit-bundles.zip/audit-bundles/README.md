# 就医伴侣 · 分角色走查资料包

基线：`2026.11.37` / commit `83a80c1`。所有行号与仓库当前版本一致。

## 目录

```
00-shared/        公共底座（提示词、目录、校验、测试、模板等小文件）
00-full-code/     完整前端与 Worker（只有 R4 需要整份上传）
r1-patient/       患者陪伴视角
r2-business/      商务讲解视角
r3-config/        配置交付视角
r4-audit/         发布质量审计（全量）
r5-redeem/        前台核销视角
r6-legal/         医务/法务视角
```

每个角色目录里：

- `PROMPT.md`：直接复制给 AI 的审计指令（含重点、红线、输出格式）
- `focus/`：该角色真正要读的代码切片，每行左侧是**仓库绝对行号**

## 推荐用法

1. 一个角色开一个 AI 会话，不要六个角色混在一起。
2. 上传该角色的 `PROMPT.md` + `focus/` 全部文件。
3. 如果 AI 上下文足够，再补 `00-shared/care-prompts.js` 和对应测试；R4 才需要整份 `frontend-index.html` 与 `worker.js`。
4. 开场只说一句：“按 PROMPT.md 执行，只依据我上传的文件，每条给文件:行号。”

## 为什么这样切

- `frontend/index.html` 5,351 行、`worker.js` 5,789 行，整份投喂会挤掉真正相关的段落。
- 六角色共用同一套内核（M1–M6），所以 `00-shared/care-prompts.js` 是唯一必须每次带的完整文件。
- 行号切片保留绝对行号，AI 的报告可以直接回到仓库定位。

## 安全

资料包只含业务代码，不含 PAT、Cloudflare Secret、`.dev.vars`。不要把登录令牌贴进任何审计对话。
